#!/usr/bin/env python3
"""
build_marswalk_presentation.py — Generates Official 16:9 7-Slide PPTX Deck for AETHON
NASA Space Apps Challenge 2026: Interplanetary Survival Guide: Martian Map
"""

import os
from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN
from pptx.enum.shapes import MSO_SHAPE

def build_presentation():
    prs = Presentation()
    prs.slide_width = Inches(13.333)
    prs.slide_height = Inches(7.5)
    blank_layout = prs.slide_layouts[6]

    # Theme Colors
    BG_DARK = RGBColor(7, 11, 16)       # #070b10
    SURFACE = RGBColor(14, 22, 34)      # #0e1622
    SURFACE2 = RGBColor(21, 34, 50)     # #152232
    CYAN = RGBColor(0, 229, 255)        # #00e5ff
    GREEN = RGBColor(0, 230, 118)       # #00e676
    AMBER = RGBColor(255, 171, 0)       # #ffab00
    ALERT = RGBColor(255, 82, 82)       # #ff5252
    TEXT_LIGHT = RGBColor(219, 232, 245)# #dbe8f5
    TEXT_MUTED = RGBColor(124, 150, 175)# #7c96af

    def apply_bg(slide):
        bg = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, 0, 0, prs.slide_width, prs.slide_height)
        bg.fill.solid()
        bg.fill.fore_color.rgb = BG_DARK
        bg.line.fill.background()

    def add_header(slide, tag_text, slide_num, title_text, sub_text):
        tag_box = slide.shapes.add_textbox(Inches(0.8), Inches(0.5), Inches(8.0), Inches(0.35))
        tf = tag_box.text_frame
        tf.word_wrap = True
        p = tf.paragraphs[0]
        p.text = tag_text.upper()
        p.font.name = "Arial"
        p.font.size = Pt(10)
        p.font.bold = True
        p.font.color.rgb = CYAN

        num_box = slide.shapes.add_textbox(Inches(9.5), Inches(0.5), Inches(3.0), Inches(0.35))
        tf_num = num_box.text_frame
        p_num = tf_num.paragraphs[0]
        p_num.text = f"SLIDE {slide_num} OF 7"
        p_num.alignment = PP_ALIGN.RIGHT
        p_num.font.name = "Arial"
        p_num.font.size = Pt(10)
        p_num.font.bold = True
        p_num.font.color.rgb = TEXT_MUTED

        t_box = slide.shapes.add_textbox(Inches(0.8), Inches(0.85), Inches(11.7), Inches(0.7))
        tf_t = t_box.text_frame
        tf_t.word_wrap = True
        p_t = tf_t.paragraphs[0]
        p_t.text = title_text
        p_t.font.name = "Arial"
        p_t.font.size = Pt(22)
        p_t.font.bold = True
        p_t.font.color.rgb = RGBColor(255, 255, 255)

        s_box = slide.shapes.add_textbox(Inches(0.8), Inches(1.5), Inches(11.7), Inches(0.4))
        tf_s = s_box.text_frame
        tf_s.word_wrap = True
        p_s = tf_s.paragraphs[0]
        p_s.text = sub_text
        p_s.font.name = "Arial"
        p_s.font.size = Pt(11)
        p_s.font.color.rgb = TEXT_MUTED

    def add_footer(slide, left_text, right_text):
        f_box = slide.shapes.add_textbox(Inches(0.8), Inches(6.9), Inches(11.7), Inches(0.35))
        tf = f_box.text_frame
        p = tf.paragraphs[0]
        p.text = f"{left_text}  •  {right_text}"
        p.font.name = "Arial"
        p.font.size = Pt(9.5)
        p.font.color.rgb = TEXT_MUTED

    # ==================== SLIDE 1 ====================
    s1 = prs.slides.add_slide(blank_layout)
    apply_bg(s1)
    add_header(s1, "Project Vision & Executive Summary", 1,
               "AETHON: Martian Field Traverse & Horizon Viewshed System",
               "Gediz Vallis Boxwork Science Traverse Planning Prototype · Lower Mount Sharp, Gale Crater")

    c1 = s1.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(0.8), Inches(2.1), Inches(5.6), Inches(4.5))
    c1.fill.solid()
    c1.fill.fore_color.rgb = SURFACE
    c1.line.color.rgb = RGBColor(34, 54, 76)
    tf1 = c1.text_frame
    tf1.margin_left = Inches(0.3)
    tf1.margin_right = Inches(0.3)
    tf1.margin_top = Inches(0.3)
    p = tf1.paragraphs[0]
    p.text = "The Exploration Planning Challenge"
    p.font.size = Pt(15)
    p.font.bold = True
    p.font.color.rgb = CYAN
    p2 = tf1.add_paragraph()
    p2.text = (
        "\n• High-Relief Martian Terrain: Future human and robotic explorers navigating ancient sedimentary channels face steep scarps, inverted gravel channels, and fracture swarms.\n\n"
        "• Data Integration Void: Mission planning requires cross-referencing orbital topography, in-situ rover observations, and regional mineralogy without inventing speculative hazards or synthetic terrain.\n\n"
        "• Geometric Line-of-Sight: Understanding what a surface camera or explorer can see requires rigorous planetary curvature corrections and real terrain ray-marching."
    )
    p2.font.size = Pt(11)
    p2.font.color.rgb = TEXT_LIGHT

    c2 = s1.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(6.8), Inches(2.1), Inches(5.7), Inches(4.5))
    c2.fill.solid()
    c2.fill.fore_color.rgb = SURFACE
    c2.line.color.rgb = RGBColor(34, 54, 76)
    tf2 = c2.text_frame
    tf2.margin_left = Inches(0.3)
    tf2.margin_right = Inches(0.3)
    tf2.margin_top = Inches(0.3)
    p = tf2.paragraphs[0]
    p.text = "The AETHON Solution"
    p.font.size = Pt(15)
    p.font.bold = True
    p.font.color.rgb = GREEN
    p2 = tf2.add_paragraph()
    p2.text = (
        "\n• 1.01m/pixel HiRISE Stereo DTM: Ingests 1,500 × 1,500 floating-point elevation raster (DTEEC_009149_1750) covering 424.2m of relief.\n\n"
        "• Verified A* Routing Engine: Implements reproducible graph search with admissible Euclidean heuristic, exact goal termination, and 20° slope trafficability cutoff.\n\n"
        "• Geometric Horizon Viewshed: Ray-traces line-of-sight and apparent skyline profiles incorporating spherical Mars curvature (R_M = 3,389.5 km).\n\n"
        "• Zero-Synthetic Science Core: All elevations, slopes, REMS observations, and rover tracks originate from NASA PDS archives."
    )
    p2.font.size = Pt(11)
    p2.font.color.rgb = TEXT_LIGHT
    add_footer(s1, "NASA Space Apps Challenge 2026", "AETHON Martian Map Planning System")

    # ==================== SLIDE 2 ====================
    s2 = prs.slides.add_slide(blank_layout)
    apply_bg(s2)
    add_header(s2, "Target Site Selection", 2,
               "Study Site: Gediz Vallis Boxwork Ridges, Gale Crater",
               "Curiosity Rover's Sol 4452 arrival at lower Mount Sharp's unique paleolake mineral ridge network.")

    stat_data = [
        ("CENTER LATITUDE", "-4.79°S", CYAN),
        ("CENTER LONGITUDE", "137.39°E", CYAN),
        ("ELEVATION RELIEF", "424.2 m", GREEN),
        ("RASTER EXTENT", "1.52 × 1.52 km", AMBER)
    ]
    for i, (lbl, val, col) in enumerate(stat_data):
        bx = s2.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(0.8 + i * 2.95), Inches(2.1), Inches(2.8), Inches(1.3))
        bx.fill.solid()
        bx.fill.fore_color.rgb = SURFACE
        bx.line.color.rgb = RGBColor(34, 54, 76)
        tf = bx.text_frame
        p = tf.paragraphs[0]
        p.text = lbl
        p.font.size = Pt(9)
        p.font.bold = True
        p.font.color.rgb = TEXT_MUTED
        p2 = tf.add_paragraph()
        p2.text = val
        p2.font.size = Pt(20)
        p2.font.bold = True
        p2.font.color.rgb = col

    site_c = s2.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(0.8), Inches(3.6), Inches(11.7), Inches(3.0))
    site_c.fill.solid()
    site_c.fill.fore_color.rgb = SURFACE
    site_c.line.color.rgb = RGBColor(34, 54, 76)
    tf_site = site_c.text_frame
    tf_site.margin_left = Inches(0.4)
    tf_site.margin_right = Inches(0.4)
    tf_site.margin_top = Inches(0.3)
    p = tf_site.paragraphs[0]
    p.text = "Geomorphological Importance & Mission Context"
    p.font.size = Pt(14)
    p.font.bold = True
    p.font.color.rgb = CYAN
    p2 = tf_site.add_paragraph()
    p2.text = (
        "\n• NASA MSL Curiosity Sol 4452 Mastcam Panorama (PIA26559): In-situ imaging acquired in May 2025 revealed prominent boxwork ridges protruding from eroded sulfate bedrock on lower Mount Sharp.\n\n"
        "• Hydrothermal Paleolake Fracture History: Mineral-rich groundwater fractured bedrock, precipitating resistant sulfate/silica vein cementation. Subsequent eolian deflation excavated the softer host rock, leaving an elevated polygonal web of mineral fins.\n\n"
        "• Scientific Objective: Plan candidate exploration traverses that maximize visual and sampling contact with boxwork triple junctions while avoiding impassable cliff scarps."
    )
    p2.font.size = Pt(11)
    p2.font.color.rgb = TEXT_LIGHT
    add_footer(s2, "NASA JPL Photojournal PIA26559", "Gediz Vallis Fan Deposit, Gale Crater")

    # ==================== SLIDE 3 ====================
    s3 = prs.slides.add_slide(blank_layout)
    apply_bg(s3)
    add_header(s3, "Data Provenance & Traceability", 3,
               "Multi-Mission NASA Planetary Data Integration",
               "Zero synthetic terrain: all topography, imagery, telemetry, and spectral footprints come from NASA archives.")

    layers = [
        ("MRO HiRISE Stereo DTM", "1.0116 m/px GeoTIFF (PSP_009149_1750 / PSP_009294_1750); true elevation -3,860.7m to -3,436.5m (424.2m relief)", "DERIVED DTM", GREEN),
        ("MRO Context Camera (CTX)", "~6 m/px context mosaic (P01_001513_1752 / P14_006622_1753) for regional visual basemap", "OBSERVED MOSAIC", CYAN),
        ("MSL Curiosity Telemetry", "99 real in-situ surface positions; Sols 4452, 4460, 4480 Mastcam imaging observation stations", "IN-SITU MOBILITY", CYAN),
        ("MRO CRISM Spectral Context", "Targeted scenes FRT0000B6F1 (18 m/px) & HRL0000BABA (36 m/px) lower Mount Sharp sulfate unit context", "REGIONAL CONTEXT", AMBER),
        ("MSL RAD & Murray Buttes M12", "RAD baseline 0.64 ± 0.12 mSv/d; Butte M12 natural shielding: 19% sky blocked → 4% dose reduction (Ehresmann et al. 2021)", "HISTORICAL BASELINE", GREEN),
        ("DAN & GRS Hydrogen Context", "DAN active neutron 1.5–3.0 wt% bound WEH in traverse swath (<1m) vs Odyssey GRS ~300 km regional proxy", "OBSERVED HYDROGEN", CYAN),
        ("Triboelectric Risk (Chide et al. 2025)", "Discharges observed at Jezero; no validated local Gale risk estimate in this release. Continuous hazard maps excluded.", "JEZERO OBSERVED", ALERT),
        ("Deliquescence Conditions (REMS Sols 4452/4460)", "Conditions potentially compatible with deliquescence; Harri/Rivera-Valentín liquid RH; geotechnical slurry penalty excluded", "CONDITIONS MODEL", AMBER)
    ]
    for i, (name, desc, badge, col) in enumerate(layers):
        y_pos = Inches(1.95 + i * 0.62)
        row = s3.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(0.8), y_pos, Inches(11.7), Inches(0.56))
        row.fill.solid()
        row.fill.fore_color.rgb = SURFACE
        row.line.color.rgb = RGBColor(34, 54, 76)
        tf = row.text_frame
        tf.margin_left = Inches(0.25)
        tf.margin_top = Inches(0.08)
        p = tf.paragraphs[0]
        p.text = f"{name}   [{badge}]"
        p.font.size = Pt(10.5)
        p.font.bold = True
        p.font.color.rgb = col
        p2 = tf.add_paragraph()
        p2.text = desc
        p2.font.size = Pt(9.0)
        p2.font.color.rgb = TEXT_LIGHT
    add_footer(s3, "NASA PDS Imaging & Geosciences Nodes", "Full Data Traceability")

    # ==================== SLIDE 4 ====================
    s4 = prs.slides.add_slide(blank_layout)
    apply_bg(s4)
    add_header(s4, "Topographic Trafficability", 4,
               "Real 1m Elevation & Slope Gradient Extraction",
               "Extracting numerical slope gradients directly from NASA PDS HiRISE stereo pairs.")

    sc_left = s4.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(0.8), Inches(2.1), Inches(5.6), Inches(4.5))
    sc_left.fill.solid()
    sc_left.fill.fore_color.rgb = SURFACE
    sc_left.line.color.rgb = RGBColor(34, 54, 76)
    tf_sc = sc_left.text_frame
    tf_sc.margin_left = Inches(0.3)
    tf_sc.margin_top = Inches(0.3)
    p = tf_sc.paragraphs[0]
    p.text = "Slope Trafficability Analysis"
    p.font.size = Pt(14)
    p.font.bold = True
    p.font.color.rgb = GREEN
    p2 = tf_sc.add_paragraph()
    p2.text = (
        "\n• Numerical Gradient: Evaluated using central finite differences on 1.0116m grid cells.\n\n"
        "• Slope Classification Thresholds:\n"
        "  - Gentle Traverse (<10°): 91.4% of study area (favorable corridors)\n"
        "  - Moderate Grade (10–15°): 7.8% of study area (climbing terrain)\n"
        "  - Steep Grade (15–20°): 0.8% of study area (approach limit)\n"
        "  - Impassable Scarp (≥20°): Strict trafficability cutoff\n\n"
        "• Real-Time Telemetry: Moving across the tactical stage dynamically reads exact latitude, longitude, elevation in meters, and analytical slope grade."
    )
    p2.font.size = Pt(11)
    p2.font.color.rgb = TEXT_LIGHT

    slope_img_p = "/home/user/aethon/data/slope_degrees.png"
    if os.path.exists(slope_img_p):
        s4.shapes.add_picture(slope_img_p, Inches(6.8), Inches(2.1), Inches(5.7), Inches(4.5))
    add_footer(s4, "NASA PDS HiRISE DTM PSP_009149_1750", "Color-Coded Slope Trafficability Grid")

    # ==================== SLIDE 5 ====================
    s5 = prs.slides.add_slide(blank_layout)
    apply_bg(s5)
    add_header(s5, "Candidate Traverse Planning Engine", 5,
               "Terrain-Aware Candidate Traverse: Graph Search Engine",
               "Evaluating reproducible ground traverses balancing path distance against slope gradient.")

    route_stats = [
        ("TOTAL DISTANCE", "688.7 m", CYAN),
        ("NET ELEVATION GAIN", "+44.7 m", GREEN),
        ("MAX SAMPLED SLOPE", "19.0°", AMBER),
        ("MEAN TRAVERSE SLOPE", "6.3°", CYAN)
    ]
    for i, (lbl, val, col) in enumerate(route_stats):
        bx = s5.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(0.8 + i * 2.95), Inches(2.1), Inches(2.8), Inches(1.3))
        bx.fill.solid()
        bx.fill.fore_color.rgb = SURFACE
        bx.line.color.rgb = RGBColor(34, 54, 76)
        tf = bx.text_frame
        p = tf.paragraphs[0]
        p.text = lbl
        p.font.size = Pt(9)
        p.font.bold = True
        p.font.color.rgb = TEXT_MUTED
        p2 = tf.add_paragraph()
        p2.text = val
        p2.font.size = Pt(20)
        p2.font.bold = True
        p2.font.color.rgb = col

    r_box = s5.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(0.8), Inches(3.6), Inches(11.7), Inches(3.0))
    r_box.fill.solid()
    r_box.fill.fore_color.rgb = SURFACE
    r_box.line.color.rgb = RGBColor(34, 54, 76)
    tf_r = r_box.text_frame
    tf_r.margin_left = Inches(0.4)
    tf_r.margin_top = Inches(0.3)
    p = tf_r.paragraphs[0]
    p.text = "Mathematical Model & Multi-Route Trade-Offs"
    p.font.size = Pt(14)
    p.font.bold = True
    p.font.color.rgb = CYAN
    p2 = tf_r.add_paragraph()
    p2.text = (
        "\n• Cost Formulation: J(P) = Σ d_i [1.0 + λ (θ_i / θ_0)^p] with λ = 1.0, θ_0 = 10.0°, and editable slope cutoff (default 20.0°).\n\n"
        "• Candidate Route Trade-Offs: Route A (direct spine: 688.7m, +44.7m, max 19.0°), Route B (low-grade margin: 782.4m, +38.2m, max 14.1°), and Route C (ridge crest: 714.2m, +58.6m, max 18.5°).\n\n"
        "• Admissible Heuristic & Exact Goal: Admissible Euclidean distance guarantees optimal paths; nodata cells are impassable barriers.\n\n"
        "• Scenario Setting (Not a Mobility Guarantee): Computational planning candidates; Curiosity telemetry is rover-specific (6-wheel rocker-bogie)."
    )
    p2.font.size = Pt(11)
    p2.font.color.rgb = TEXT_LIGHT
    add_footer(s5, "A* Slope-Aware Routing · Multi-Route Trade-Offs", "Scenario Assumptions Only")

    # ==================== SLIDE 6 ====================
    s6 = prs.slides.add_slide(blank_layout)
    apply_bg(s6)
    add_header(s6, "Solar Illumination & Terrain Radiation Shielding", 6,
               "Solar Ephemeris, Cliff Shadows & Terrain Radiation Shielding",
               "Predicting diurnal solar lighting and evaluating two-tier natural radiation shelter potential.")

    c6_1 = s6.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(0.8), Inches(2.1), Inches(5.6), Inches(4.5))
    c6_1.fill.solid()
    c6_1.fill.fore_color.rgb = SURFACE
    c6_1.line.color.rgb = RGBColor(34, 54, 76)
    tf6_1 = c6_1.text_frame
    tf6_1.margin_left = Inches(0.3)
    tf6_1.margin_top = Inches(0.3)
    p = tf6_1.paragraphs[0]
    p.text = "Solar Ephemeris & Cliff Shadows"
    p.font.size = Pt(14)
    p.font.bold = True
    p.font.color.rgb = CYAN
    p2 = tf6_1.add_paragraph()
    p2.text = (
        "\n• NASA Mars24 Ephemeris: Computes solar altitude and azimuth from Allison & McEwen (2000) equations across diurnal cycle (Sol 4452 Ls = 84.3°).\n\n"
        "• Terrain Solar Ray-Tracing: Evaluates direct sunlight vs cliff shadows with Mars curvature drop (R_M = 3,389.5 km) and ±0.25m vertical precision.\n\n"
        "• 4-State Visibility: Classifies target line-of-sight into VISIBLE, OCCLUDED, UNCERTAIN AT DTM RESOLUTION (grazing within ±0.25m), or INSUFFICIENT COVERAGE.\n\n"
        "• Crucial Scientific Distinction: Optical shadow blocks direct solar photons for lighting/thermal context; it does NOT provide omnidirectional GCR radiation shielding."
    )
    p2.font.size = Pt(10.5)
    p2.font.color.rgb = TEXT_LIGHT

    c6_2 = s6.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(6.8), Inches(2.1), Inches(5.7), Inches(4.5))
    c6_2.fill.solid()
    c6_2.fill.fore_color.rgb = SURFACE
    c6_2.line.color.rgb = RGBColor(34, 54, 76)
    tf6_2 = c6_2.text_frame
    tf6_2.margin_left = Inches(0.3)
    tf6_2.margin_top = Inches(0.3)
    p = tf6_2.paragraphs[0]
    p.text = "Terrain Radiation Shielding (Tiers 1 & 2)"
    p.font.size = Pt(14)
    p.font.bold = True
    p.font.color.rgb = GREEN
    p2 = tf6_2.add_paragraph()
    p2.text = (
        "\n• Tier 1 Geometry-Only Shelter Potential: 360° horizon ray-march (72 sectors) computes blocked sky solid angle (Ω_blocked) and fraction (F_blocked). Prominently labeled: 'Geometry only; not a dose estimate.'\n\n"
        "• Empirical Murray Buttes Validation: MSL RAD observed Butte M12 (Sols 1456–1467): 19% sky view blocked produced 4.0% ± 1.2% dose reduction and 7.5% neutral-particle reduction (Ehresmann et al. 2021).\n\n"
        "• Tier 2 Transport Benchmark: GEANT4 downward zenith model (Khaksari et al. 2022) with secondary albedo neutrons in rock mass (η ≈ 0.80), reproducing M12 benchmark.\n\n"
        "• Research Prototype Scope: Planning aid only; never label a route or shelter 'safe.'"
    )
    p2.font.size = Pt(10.5)
    p2.font.color.rgb = TEXT_LIGHT
    add_footer(s6, "Mars24 Ephemeris · MSL RAD Shielding Benchmark", "AETHON Exploration Systems")

    # ==================== SLIDE 7 ====================
    s7 = prs.slides.add_slide(blank_layout)
    apply_bg(s7)
    add_header(s7, "Methodology & Operational Scope", 7,
               "Methodology, Scientific Scope & Software Quality",
               "Rigorous, honest engineering that bridges planetary data archives with exploration planning.")

    principles = [
        ("Research Prototype Scope", "AETHON is a research planning tool for candidate traverse evaluation and line-of-sight estimation. Outputs are planning aids, not flight-ready EVA safety advice or human life-support guidance. Never label a route or shelter 'safe.'", GREEN),
        ("Scientific Integrity & Sourced Constraints", "CRISM spectral units provide regional stratigraphic context (~18–36 m/px); REMS readings are dated point observations; no accessible water exists at this equatorial site; Jezero electrostatics are not extrapolated to Gale.", CYAN),
        ("Two-Tier Validation Hierarchy", "Tier 1: 43 automated unit tests across 5 QA modules (DTM bounds, A* graph search, 4-state viewshed, Mars24 solar shadows, and radiation shelter integration). Tier 2 Scientific Manifest verifies photogrammetric precision and M12 validation.", AMBER),
        ("Offline Zero-Dependency Delivery", "Runs cleanly in any standard web browser via Python's built-in HTTP server without external CDNs, npm builds, or internet access required.", RGBColor(255, 255, 255))
    ]
    for i, (p_title, p_desc, col) in enumerate(principles):
        y_pos = Inches(2.0 + i * 1.15)
        p_card = s7.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(0.8), y_pos, Inches(11.7), Inches(1.05))
        p_card.fill.solid()
        p_card.fill.fore_color.rgb = SURFACE
        p_card.line.color.rgb = RGBColor(34, 54, 76)
        tf = p_card.text_frame
        tf.margin_left = Inches(0.3)
        tf.margin_top = Inches(0.12)
        p = tf.paragraphs[0]
        p.text = p_title
        p.font.size = Pt(12)
        p.font.bold = True
        p.font.color.rgb = col
        p2 = tf.add_paragraph()
        p2.text = p_desc
        p2.font.size = Pt(10)
        p2.font.color.rgb = TEXT_LIGHT
    add_footer(s7, "NASA Space Apps Challenge 2026 Submission Complete", "AETHON Exploration Systems")

    out_path = "/home/user/aethon/AETHON_7Slide_Presentation.pptx"
    prs.save(out_path)
    print(f"Successfully generated official 7-slide presentation deck: {out_path} ({os.path.getsize(out_path)} bytes)")

if __name__ == "__main__":
    build_presentation()
